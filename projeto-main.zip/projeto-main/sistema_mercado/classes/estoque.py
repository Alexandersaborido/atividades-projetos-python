
class Estoque:
    def __init__(self):
        self.produtos = {}

    # Adicionar produtos
    def adicionar_produto(self, produto):
        chave = produto.nome.strip().lower()

        if chave in self.produtos:
            print("Produto já adicionado!")
        else:
            self.produtos[chave] = produto
            print("Produto cadastrado com sucesso!")

    # Remover produto inteiro
    def remover_produto(self, nome):
        chave = nome.strip().lower()

        if chave in self.produtos:
            del self.produtos[chave]
            print(f"{nome} removido com sucesso!")
        else:
            print("Produto não encontrado.")

    # Adicionar quantidade
    def adicionar_quantidade(self, nome, quantidade):
        chave = nome.strip().lower()

        if chave not in self.produtos:
            print("Produto não encontrado.")
            return

        produto = self.produtos[chave]
        if quantidade <=0:
            print("Digite uma quantidade válida!")
            return
        else:
            produto.quantidade += quantidade
            print(f"{quantidade} unidades de {produto.nome} adicionadas!")

    # Remover determinada quantidade
    def remover_quantidade(self, nome, quantidade):
        chave = nome.strip().lower()

        if chave not in self.produtos:
            print("Produto não encontrado.")
            return

        produto = self.produtos[chave]

        if quantidade <= 0:
            print("Digite uma quantidade válida!")
            return

        if quantidade <= produto.quantidade:
            produto.quantidade -= quantidade

            print(f"{quantidade} unidades de {produto.nome} removidas!")

            if produto.quantidade == 0:
                del self.produtos[chave]
                print(f"{produto.nome} foi removido do estoque.")
        else:
            print("Quantidade maior do que a disponível!")

    # Mostrar todos os produtos
    def listar_produtos(self):
        if not self.produtos:
            print("Não existe nenhum produto no estoque.")
        else:
            for produto in self.produtos.values():
                print(
                    f"Nome: {produto.nome} | "
                    f"Quantidade: {produto.quantidade} | "
                    f"Preço: R$ {produto.preco:.2f}"
                )
