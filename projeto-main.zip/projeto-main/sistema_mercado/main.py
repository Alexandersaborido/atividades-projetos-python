
from sistema_mercado.classes.produtos import Produto
from sistema_mercado.classes.estoque import Estoque

import time
import sys

estoque = Estoque()

while True:
    print("---- CADASTRO DE PRODUTOS ----")
    print("1 - Adicionar produtos")
    print("2 - Remover produtos")
    print("3 - Remover quantidade de um produto")
    print("4 - Mostrar lista de produtos")
    print("5 - Encerrar programa")

    opcao = input("Digite a opção: ")

    # Adiciona o produto
    if opcao == "1":
        nome = input("Digite o nome do produto: ")
        quant = int(input("Digite a quantidade: "))
        preco = float(input("Digite o preço: "))

        produto = Produto(nome, quant, preco)

        estoque.adicionar_produto(produto)

    # Remove o produto
    elif opcao == "2":
        nome = input("Digite o nome do produto que deseja remover: ")

        estoque.remover_produto(nome)

    # Adiciona quantidade de um produto
    elif opcao == "3":
        nome = input("Digite o nome do produto: ")
        quant = int(input("Digite a quantidade que deseja adicionar: "))

        estoque.adicionar_quantidade
        
    # Remove uma quantidade de algum produto
    elif opcao == "4":
        nome = input("Digite o nome do produto: ")
        quant = int(input("Digite a quantidade que deseja remover: "))

        estoque.remover_quantidade(nome, quant)

    # Mostra a lista de produtos
    elif opcao == "5":
        estoque.listar_produtos()

    # Encerra o programa
    elif opcao == "6":
        print("Encerrando o programa", end="")

        for i in range(3):
            time.sleep(0.7)
            print(".", end="")
            sys.stdout.flush()

        print("\nPrograma encerrado com sucesso!")
        break

    else:
        print("Opção não encontrada!")
